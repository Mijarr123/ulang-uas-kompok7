// masuk ke elemen DOM
const gameContainer = document.querySelector(".container"),
  userResult = document.querySelector(".user_result img"),
  cpuResult = document.querySelector(".cpu_result img"),
  result = document.querySelector(".result"),
  optionImages = document.querySelectorAll(".option_image");

// opsi mengulangi setiap elemen gambar
optionImages.forEach((image, index) => {
  image.addEventListener("click", (e) => {
    image.classList.add("active");

    userResult.src = cpuResult.src = "images/rock.png";
    result.textContent = "Tunggu...";

    // ulangi lagi setiap memilih gambar
    optionImages.forEach((image2, index2) => {
      index !== index2 && image2.classList.remove("active");
    });

    gameContainer.classList.add("start");

    // terapkan batas waktu untuk menunda perhitungan hasil
    let time = setTimeout(() => {
      gameContainer.classList.remove("start");

      // dapatkan sumber gambar opsi yang di klik
      let imageSrc = e.target.querySelector("img").src;
      // mengatur gambar pengguna ke opsi yang di klik
      userResult.src = imageSrc;

      // hasilkan bilangan acak antara 0 dan 2
      let randomNumber = Math.floor(Math.random() * 3);
      // membuat gambar CPU
      let cpuImages = [
        "images/rock.png",
        "images/paper.png",
        "images/scissors.png",
      ];
      // atur gambar CPU ke opsi acak dari array
      cpuResult.src = cpuImages[randomNumber];

      // menetapkan nilai huruf pada opsi CPU (R untuk batu, P untuk kertas, S untuk gunting)
      let cpuValue = ["R", "P", "S"][randomNumber];
      // mentapkan nilai huruf pada opsi yang di klik (berdasarkan index)
      let userValue = ["R", "P", "S"][index];

      // membuat objek dengan semua kemungkinan hasil
      let outcomes = {
        RR: "Draw",
        RP: "Kamu",
        RS: "Kamu",
        PP: "Draw",
        PR: "Kamu",
        PS: "Computer",
        SS: "Draw",
        SR: "Computer",
        SP: "Kamu",
      };

      // cari nilai hasil berdasarkan opsi pengguna dan CPU
      let outComeValue = outcomes[userValue + cpuValue];

      // untuk menampilkan hasilnya
      result.textContent =
        userValue === cpuValue ? "Kalian Seri !" : `${outComeValue} Menang!`;
    }, 2500);
  });
});
